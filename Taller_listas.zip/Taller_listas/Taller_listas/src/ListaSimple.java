public class ListaSimple {
    private Nodo cabeza;
    private Nodo cola;

    // Clase interna para representar un nodo
    private class Nodo {
        int dato;
        Nodo siguiente;

        public Nodo(int dato) {
            this.dato = dato;
            this.siguiente = null;
        }
    }

    // Agregar un nodo al inicio de la lista
    public void agregarAlInicio(int dato) {
        Nodo nuevo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevo;
            cola = nuevo;
        } else {
            nuevo.siguiente = cabeza;
            cabeza = nuevo;
        }
    }

    // Agregar un nodo al final de la lista
    public void agregarAlFinal(int dato) {
        Nodo nuevo = new Nodo(dato);
        if (cabeza == null) {
            cabeza = nuevo;
            cola = nuevo;
        } else {
            cola.siguiente = nuevo;
            cola = nuevo;
        }
    }

    // Buscar un nodo en la lista
    public boolean buscar(int dato) {
        Nodo actual = cabeza;
        while (actual != null) {
            if (actual.dato == dato) {
                return true; // Nodo encontrado
            }
            actual = actual.siguiente;
        }
        return false; // Nodo no encontrado
    }

    // Imprimir la lista
    public void imprimir() {
        Nodo actual = cabeza;
        while (actual != null) {
            System.out.print(actual.dato + " -> ");
            actual = actual.siguiente;
        }
        System.out.println("null");
    }

    // Método de prueba
    public static void main(String[] args) {
        ListaSimple lista = new ListaSimple();

        lista.agregarAlInicio(3);
        lista.agregarAlInicio(2);
        lista.agregarAlInicio(1);
        lista.imprimir(); 

        lista.agregarAlFinal(4);
        lista.agregarAlFinal(5);
        lista.imprimir(); 

        System.out.println("¿Existe el 3? " + lista.buscar(3)); // true
        System.out.println("¿Existe el 6? " + lista.buscar(6)); // false
    }
}
