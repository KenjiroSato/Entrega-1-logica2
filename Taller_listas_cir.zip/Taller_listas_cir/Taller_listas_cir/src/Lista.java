
import javax.swing.JOptionPane;

public class Lista {
    Nodo  ultimo;
    public Lista() {
        this.ultimo = null;
    }
    public  boolean estaVacia() {
        return this.ultimo == null;
    }
    public Lista insertar(int dato) {
        Nodo nuevo = new Nodo(dato);
        if (this.ultimo == null) {
            this.ultimo = nuevo;
            this.ultimo.siguiente = this.ultimo;
        } else {
            nuevo.siguiente = this.ultimo.siguiente;
            this.ultimo.siguiente = nuevo;
            this.ultimo = nuevo;
        }
        return this;
    }
    public void mostrarlista(){
        Nodo aux = this.ultimo.siguiente;
        String cadena="";
        do { 
            cadena = cadena + aux.dato + " " + " -->";
        } while (aux != this.ultimo.siguiente);
        JOptionPane.showMessageDialog(null, cadena, "Mostrando la lista circular", JOptionPane.INFORMATION_MESSAGE);
        
    }

}
