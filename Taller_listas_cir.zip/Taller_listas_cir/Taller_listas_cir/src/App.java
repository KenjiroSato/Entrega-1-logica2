import javax.swing.JOptionPane;

public class App {
    public static void main(String[] args) throws Exception {
        Lista lista = new Lista();
        int opcion = 0, dato;
        do {
            try {
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "1. Agregar un nodo\n2. Mostrar lista\n3. Salir\n¿Qué desea hacer?", "Menú de opciones",
                        JOptionPane.INFORMATION_MESSAGE));
                switch (opcion) {
                    case 1:
                        dato = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el dato del nodo",
                                "Agregando nodo a la lista circular", JOptionPane.INFORMATION_MESSAGE));
                        lista.insertar(dato);
                        break;
                    case 2:
                        if (!lista.estaVacia()) {
                            lista.mostrarlista();
                        } else {
                            JOptionPane.showMessageDialog(null, "La lista está vacía", "Lista vacía",
                                    JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 3:
                        JOptionPane.showMessageDialog(null, "Aplicación finalizada", "Fin", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción incorrecta", "Error", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Error" + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } while (opcion != 3);
    }
}
